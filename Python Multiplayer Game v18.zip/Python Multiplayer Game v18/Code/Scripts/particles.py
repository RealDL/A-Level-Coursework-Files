from Scripts.logger import * 
try:  
	import pygame, string, random
	from Scripts.settings import Config
	from Scripts.support import import_folder
except:
    logger.critical("You do not have all the modules installed. Please install Pygame.")

logger.debug("RealDL Magic Code.")

class AnimationPlayer:
	def __init__(self):
		self.particles = None
		self.frames = {
			# magic
			'flame': import_folder('Graphics/Game/particles/flame/frames'),
			'aura': import_folder('Graphics/Game/particles/aura'),
			'heal': import_folder('Graphics/Game/particles/heal/frames'),

			# leafs 
			'leaf': (
				import_folder('Graphics/Game/particles/leaf1'),
				import_folder('Graphics/Game/particles/leaf2'),
				import_folder('Graphics/Game/particles/leaf3'),
				import_folder('Graphics/Game/particles/leaf4'),
				import_folder('Graphics/Game/particles/leaf5'),
				import_folder('Graphics/Game/particles/leaf6'),
				self.reflect_images(import_folder('Graphics/Game/particles/leaf1')),
				self.reflect_images(import_folder('Graphics/Game/particles/leaf2')),
				self.reflect_images(import_folder('Graphics/Game/particles/leaf3')),
				self.reflect_images(import_folder('Graphics/Game/particles/leaf4')),
				self.reflect_images(import_folder('Graphics/Game/particles/leaf5')),
				self.reflect_images(import_folder('Graphics/Game/particles/leaf6'))
				)
			}
			
		
		self.images = {
			# magic
			'flame': import_folder('Graphics/Game/particles/flame/frames',None),
			'aura': import_folder('Graphics/Game/particles/aura',None),
			'heal': import_folder('Graphics/Game/particles/heal/frames',None),

			# leafs 
			'leaf': (
				import_folder('Graphics/Game/particles/leaf1',None),
				import_folder('Graphics/Game/particles/leaf2',None),
				import_folder('Graphics/Game/particles/leaf3',None),
				import_folder('Graphics/Game/particles/leaf4',None),
				import_folder('Graphics/Game/particles/leaf5',None),
				import_folder('Graphics/Game/particles/leaf6',None),
				# inverted
				import_folder('Graphics/Game/particles/leaf1',None),
				import_folder('Graphics/Game/particles/leaf2',None),
				import_folder('Graphics/Game/particles/leaf3',None),
				import_folder('Graphics/Game/particles/leaf4',None),
				import_folder('Graphics/Game/particles/leaf5',None),
				import_folder('Graphics/Game/particles/leaf6',None),
				)
			}
		
	def reflect_images(self,frames):
		# transforms image horazontally
		new_frames = []
		for frame in frames:
			fipped_frame = pygame.transform.flip(frame,True,False)
			new_frames.append(fipped_frame)
		return new_frames
	
	def create_grass_particles(self,pos,groups):
		inverted = False
		random_choice = random.randint(0,len(self.images['leaf'])-1)
		if random_choice > 5:
			inverted = True
		animation_frames = self.frames['leaf'][random_choice]
		animation_images = self.images['leaf'][random_choice]
		ParticleEffect(pos,animation_frames,animation_images,"leaf",groups,inverted)

	def create_particles(self,animation_type,pos,strength,groups,player_id):
		animation_frames = self.frames[animation_type]
		animation_images = self.images[animation_type]
		self.particles = ParticleEffect(pos,animation_frames,animation_images,animation_type,groups,None,strength,player_id)

class ParticleEffect(pygame.sprite.Sprite):
	def __init__(self,pos,animation_frames,animation_images,animation_type,groups,inverted=None,strength=None,player_id=None):
		super().__init__(groups)
		self.settings = Config()
		self.sprite_type = 'magic'
		self.strength = strength
		self.damaged_player = False
		self.animation_type = animation_type
		self.inverted = inverted
		self.id = self.create_id()
		self.player_id = player_id
		self.frame_index = 0
		self.animation_speed = 0.15*(self.settings.frame_increase_rate/1.5)
		self.frames = animation_frames
		self.images = animation_images
		self.image = self.frames[self.frame_index]
		self.rect = self.image.get_rect(center = pos)

	def animate(self, dt):
		self.frame_index += self.animation_speed  * dt
		if self.frame_index >= len(self.frames):
			self.kill()
		else:
			self.image = self.frames[int(self.frame_index)]

	def return_type(self):
		return self.animation_type
	
	def return_strength(self):
		return self.strength

	def return_image(self):
		self.full_path = self.images[int(self.frame_index)]
		if "../" in self.full_path:
			self.full_path = self.full_path.replace("../","")
		return self.full_path
	
	def return_inverted(self):
		return self.inverted
	
	def create_id(self):
		try:
			characters = string.ascii_letters + string.digits
			return ''.join(random.choice(characters) for _ in range(self.settings.ID_STRING_LENGTH))
		except:
			logger.error("Something went wrong with creating a unique ID.")

	def update(self, dt):
		self.animate(dt)
